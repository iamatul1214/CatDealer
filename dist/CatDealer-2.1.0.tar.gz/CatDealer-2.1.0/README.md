# NanDealer 
This library takes your dataframe with categorical data and converts it into numerical one. This library has some functions which can perform removal and encoding of the dataset.
## Installation
pip install CatDealer

## How to use it?
Step 1: Import the Catdealer class.\
Step 2: Read any dataframe.\
step 3: Pass your dataframe to the Categorical values converting methods of the CatDealer class.\
step 4: You will receive a dataframe with Categorical values converted according to the method used and the dataframe will be free from all categorical columns.\

## You can see the example of that in Test.py class by navigating to github.

## License
MIT License

